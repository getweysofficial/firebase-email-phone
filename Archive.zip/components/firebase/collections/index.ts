export enum FirestoreCollection {
    USERS = 'users',
}

// Never change this key. This key must match the key in /firestore.rules
export const FirestoreUserKey = 'userUID';
