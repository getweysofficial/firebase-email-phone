export enum v1APIRoute {
    fetchHomePageData = 'fetchHomePageData',
}
