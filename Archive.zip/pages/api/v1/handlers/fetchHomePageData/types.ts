/* eslint-disable @typescript-eslint/no-empty-interface */
export interface FetchHomePageDataInput {}
export interface FetchHomePageDataOutput {
    success: boolean;
}
