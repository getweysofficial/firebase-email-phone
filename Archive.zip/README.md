# Onboarding Video

https://www.loom.com/share/1167ce5c38f54f9590ef31a7426c25e2


## Required

- Install Firebase CLI https://firebase.google.com/docs/cli
- Download JDK https://www.oracle.com/java/technologies/downloads/#java21
